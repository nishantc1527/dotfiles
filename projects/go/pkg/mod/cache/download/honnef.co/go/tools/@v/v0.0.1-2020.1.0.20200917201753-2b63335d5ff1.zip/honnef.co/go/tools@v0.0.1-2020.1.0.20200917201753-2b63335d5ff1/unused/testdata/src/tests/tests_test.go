package pkg

import "testing"

func TestFn(t *testing.T) { // used_test
	fn()
}
