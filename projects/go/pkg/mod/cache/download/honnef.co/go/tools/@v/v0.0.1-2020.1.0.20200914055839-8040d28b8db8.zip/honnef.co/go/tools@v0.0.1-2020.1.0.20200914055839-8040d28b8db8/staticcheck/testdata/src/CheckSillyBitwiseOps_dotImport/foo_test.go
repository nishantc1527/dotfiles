package foo_test

import . "CheckSillyBitwiseOps_dotImport"

var _ = 1 | X
