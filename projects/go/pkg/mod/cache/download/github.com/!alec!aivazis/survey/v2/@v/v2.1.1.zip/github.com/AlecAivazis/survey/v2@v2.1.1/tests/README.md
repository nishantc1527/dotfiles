# survey/tests

Because of the nature of this library, I was having a hard time finding a reliable
way to run unit tests, therefore I decided to try to create a suite
of integration tests which must be run successfully before a PR can be merged.
I will try to add to this suite as new edge cases are known.
