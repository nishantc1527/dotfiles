// +build !race

package httpretty

var Race = false
