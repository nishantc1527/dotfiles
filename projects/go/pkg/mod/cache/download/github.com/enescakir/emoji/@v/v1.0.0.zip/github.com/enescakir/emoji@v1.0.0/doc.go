/*
Package emoji makes working with emojis easier.
*/
package emoji
