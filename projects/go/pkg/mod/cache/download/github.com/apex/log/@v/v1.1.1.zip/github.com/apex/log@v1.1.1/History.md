
v1.1.1 / 2019-06-24
===================

  * add go.mod
  * add rough pass at apexlogs handler

v1.1.0 / 2018-10-11
===================

  * fix: cli handler to show non-string fields appropriately
  * fix: cli using fatih/color to better support windows
