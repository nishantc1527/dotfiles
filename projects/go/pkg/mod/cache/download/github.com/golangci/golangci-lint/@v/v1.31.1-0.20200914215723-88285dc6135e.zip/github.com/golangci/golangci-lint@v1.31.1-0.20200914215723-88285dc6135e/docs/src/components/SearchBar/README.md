The source code copy-pasted from [here](https://github.com/facebook/docusaurus/blob/master/packages/docusaurus-theme-search-algolia/src/theme/SearchBar/).

Waiting for [the official component](https://github.com/algolia/docsearch/issues/689).
