//args: -Eunused
package p

type (
	unused struct{}
)

func X() {}
